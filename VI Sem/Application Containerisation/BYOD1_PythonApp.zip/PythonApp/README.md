# PythonApp

A simple Flask web application that serves a welcome page and a health check endpoint.

---

## Project Structure

```
PythonApp/
├── app.py                  # Main application entry point
├── requirements.txt        # Python dependencies
├── templates/
│   ├── base.html           # Base HTML template
│   └── index.html          # Home page template
└── static/
    └── css/
        └── style.css       # Stylesheet
```

---

## Prerequisites

Make sure the following are installed on your machine before running the app:

- **Python 3.10 or higher** — [Download](https://www.python.org/downloads/)
- **pip** (comes bundled with Python)

Verify your installation:

```bash
python --version
pip --version
```

---

## Running the App Locally

### Step 1 — Clone or download the project

If you received a zip file, extract it and navigate into the project folder:

```bash
cd PythonApp
```

### Step 2 — Create a virtual environment

```bash
python -m venv venv
```

Activate it:

- **macOS / Linux:**
  ```bash
  source venv/bin/activate
  ```
- **Windows:**
  ```bash
  venv\Scripts\activate
  ```

### Step 3 — Install dependencies

```bash
pip install -r requirements.txt
```

### Step 4 — Run the application

```bash
python app.py
```

You should see output like:

```
 * Running on http://0.0.0.0:5000
 * Press CTRL+C to quit
```

### Step 5 — Open the app in your browser

- Home page: [http://localhost:5000](http://localhost:5000)
- Health check: [http://localhost:5000/health](http://localhost:5000/health)

---

## Environment Variables

The app supports the following optional environment variables:

| Variable   | Default          | Description                      |
|------------|------------------|----------------------------------|
| `PORT`     | `5000`           | Port the app listens on          |
| `APP_NAME` | `Flask Docker App` | Title shown on the home page   |

Example:

```bash
APP_NAME="My Custom App" PORT=8080 python app.py
```

---

## Stopping the App

Press `CTRL + C` in the terminal to stop the server.

---

## Exam Tasks & Marking Scheme

**Total Marks: 50 | Duration: 2 Hours**

Complete all tasks below. After each task, **take a screenshot** as evidence. Compile all screenshots into a single PDF and submit it before the exam ends.

---

### Task 1 — Run the App Locally `[8 marks]`

Follow the steps in the **Running the App Locally** section above to get the application running on your machine.

| Step | Marks |
|------|-------|
| Virtual environment created and activated | 2 |
| Dependencies installed via `pip install -r requirements.txt` | 2 |
| App starts without errors (`python app.py`) | 2 |
| Home page visible at `http://localhost:5000` in the browser | 2 |

**Screenshot required:** Browser showing the home page at `http://localhost:5000`.

---

### Task 2 — Write a Dockerfile `[12 marks]`

Create a file named `Dockerfile` in the root of the project directory. It must containerize this Flask application correctly.

| Requirement | Marks |
|-------------|-------|
| Uses an official Python base image (e.g. `python:3.11` or `python:3.11-slim`) | 2 |
| Sets a working directory inside the container using `WORKDIR` | 2 |
| Copies `requirements.txt` and runs `pip install` before copying the rest of the code | 3 |
| Copies the remaining application files into the container | 2 |
| Exposes the correct port (`5000`) | 1 |
| Sets the correct command to start the application | 2 |

**Screenshot required:** Your `Dockerfile` open in a text editor or terminal (`cat Dockerfile`).

---

### Task 3 — Build the Docker Image `[8 marks]`

Build a Docker image from your Dockerfile and tag it with your Docker Hub username.

```bash
docker build -t <your-dockerhub-username>/pythonapp:latest .
```

| Step | Marks |
|------|-------|
| Build command is correct and includes a tag | 3 |
| Build completes successfully with no errors | 3 |
| Image appears in `docker images` list | 2 |

**Screenshot required:** Terminal showing the successful build output and `docker images` listing your image.

---

### Task 4 — Run the Container `[10 marks]`

Run your Docker image as a container and verify the app is accessible from your host machine.

```bash
docker run -d -p 5000:5000 <your-dockerhub-username>/pythonapp:latest
```

| Step | Marks |
|------|-------|
| Container runs in detached mode (`-d` flag) | 2 |
| Correct port mapping used (`-p 5000:5000`) | 3 |
| Container is running (visible in `docker ps`) | 2 |
| App is accessible at `http://localhost:5000` in the browser | 3 |

**Screenshot required:** Terminal showing `docker ps` with your running container AND the browser showing the app at `http://localhost:5000`.

---

### Task 5 — Push the Image to Docker Hub `[12 marks]`

Log in to Docker Hub from your terminal and push your image.

```bash
docker login
docker push <your-dockerhub-username>/pythonapp:latest
```

| Step | Marks |
|------|-------|
| Successfully logged in to Docker Hub (`docker login`) | 2 |
| Push command is correct | 2 |
| Image pushes successfully (all layers pushed) | 4 |
| Image is visible on your Docker Hub profile (`hub.docker.com`) | 4 |

**Screenshot required:** Terminal showing the successful push output AND your Docker Hub profile page showing the `pythonapp` repository.

---

### Submission Instructions

1. Collect all screenshots from Tasks 1–5 (minimum **6 screenshots** total).
2. Arrange them in task order inside a single PDF document.
3. Label each screenshot clearly (e.g., *Task 1 — App running locally*).
4. Name your PDF file: `<YourFullName>_Docker_Exam.pdf`
5. Submit the PDF before the exam ends.

> **Note:** Marks will only be awarded for tasks evidenced by a screenshot. Ensure your Docker Hub username and terminal output are clearly visible in your screenshots.

---

*Good luck!*
