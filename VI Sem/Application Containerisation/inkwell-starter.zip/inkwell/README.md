# Inkwell — Blog Platform

A simple full-stack blog app with a React frontend, Node.js/Express backend,
PostgreSQL database, and Redis cache.

## Stack

| Service    | Technology         | Port  |
|------------|--------------------|-------|
| frontend   | React + Nginx      | 3000  |
| backend    | Node.js + Express  | 5000  |
| db         | PostgreSQL 16      | 5432  |
| cache      | Redis 7            | 6379  |

## Your task

Create a `docker-compose.yml` at the root of this project that:

1. Defines all four services above
2. Passes environment variables from a `.env` file to the right containers
3. Puts all services on a shared custom network called `inkwell-net`
4. Persists PostgreSQL data using a named volume called `pgdata`
5. Makes the backend wait for the database to be healthy before starting

## Getting started

```bash
# 1. Create your env file
cp .env.example .env

# 2. Write your docker-compose.yml (this is the assignment!)

# 3. Start everything
docker compose up --build

# 4. Open the app
open http://localhost:3000
```

## API endpoints

| Method | Path          | Description              |
|--------|---------------|--------------------------|
| GET    | /health       | Health check             |
| GET    | /posts        | List all posts           |
| POST   | /posts        | Create a post            |
| DELETE | /posts/:id    | Delete a post by ID      |

### POST /posts — request body

```json
{
  "title": "My first post",
  "content": "Hello from Inkwell!",
  "author": "Alice"
}
```

## Hints

- The backend `Dockerfile` uses a multi-stage build. You don't need to change it.
- The frontend `Dockerfile` accepts a build argument: `REACT_APP_API_URL`.
  Pass it using the `build.args` key in Compose so the React app knows where
  the API lives.
- PostgreSQL's data directory inside the container is `/var/lib/postgresql/data`.
- To check if PostgreSQL is ready, use the `pg_isready` command.
- Redis doesn't need a health check — it starts almost instantly.

## Project structure

```
inkwell/
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── Dockerfile
│   ├── package.json
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── index.js
│       └── App.jsx
├── .env.example
├── .gitignore
└── README.md          ← you are here

# You will add:
└── docker-compose.yml ← your task
```
