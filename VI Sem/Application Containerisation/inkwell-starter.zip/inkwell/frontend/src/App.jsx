import React, { useState, useEffect, useCallback } from "react";

// The API URL is injected at build time via an environment variable.
// In Docker Compose, REACT_APP_API_URL will point to the backend service.
const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";

/* ─── Styles ──────────────────────────────────────────────────────────────── */
const S = {
  app: {
    minHeight: "100vh",
    background: "#f5f5f0",
    padding: "0 0 4rem",
  },
  header: {
    background: "#fff",
    borderBottom: "1px solid #e5e5e0",
    padding: "1rem 0",
    marginBottom: "2rem",
  },
  headerInner: {
    maxWidth: 720,
    margin: "0 auto",
    padding: "0 1.5rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  logo: { fontSize: 22, fontWeight: 600, letterSpacing: -0.5, margin: 0 },
  status: { fontSize: 12, display: "flex", alignItems: "center", gap: 6 },
  dot: (ok) => ({
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: ok ? "#22c55e" : "#ef4444",
  }),
  main: { maxWidth: 720, margin: "0 auto", padding: "0 1.5rem" },
  card: {
    background: "#fff",
    border: "1px solid #e5e5e0",
    borderRadius: 10,
    padding: "1.25rem 1.5rem",
    marginBottom: "1rem",
  },
  form: {
    background: "#fff",
    border: "1px solid #e5e5e0",
    borderRadius: 10,
    padding: "1.25rem 1.5rem",
    marginBottom: "1.5rem",
  },
  formTitle: { fontSize: 15, fontWeight: 600, marginBottom: 12 },
  input: {
    width: "100%",
    padding: "8px 10px",
    border: "1px solid #ddd",
    borderRadius: 6,
    fontSize: 14,
    marginBottom: 10,
    outline: "none",
    fontFamily: "inherit",
  },
  textarea: {
    width: "100%",
    padding: "8px 10px",
    border: "1px solid #ddd",
    borderRadius: 6,
    fontSize: 14,
    marginBottom: 10,
    outline: "none",
    resize: "vertical",
    fontFamily: "inherit",
    minHeight: 90,
  },
  row: { display: "flex", gap: 8 },
  btn: (variant) => ({
    padding: "8px 16px",
    borderRadius: 6,
    border: "none",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 500,
    background: variant === "primary" ? "#1a1a1a" : "#f0f0ec",
    color: variant === "primary" ? "#fff" : "#333",
    flex: variant === "primary" ? 1 : "unset",
  }),
  postTitle: { fontSize: 16, fontWeight: 600, margin: "0 0 4px" },
  postMeta: { fontSize: 12, color: "#888", margin: "0 0 10px" },
  postContent: { fontSize: 14, color: "#333", lineHeight: 1.65, margin: 0 },
  deleteBtn: {
    marginTop: 12,
    padding: "4px 10px",
    fontSize: 12,
    border: "1px solid #e5e5e0",
    borderRadius: 5,
    background: "transparent",
    cursor: "pointer",
    color: "#888",
  },
  empty: { textAlign: "center", color: "#aaa", padding: "3rem 0", fontSize: 14 },
  sectionLabel: {
    fontSize: 11,
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "#aaa",
    marginBottom: 10,
  },
  error: {
    background: "#fef2f2",
    border: "1px solid #fecaca",
    color: "#b91c1c",
    borderRadius: 8,
    padding: "10px 14px",
    fontSize: 13,
    marginBottom: 12,
  },
};

/* ─── App ─────────────────────────────────────────────────────────────────── */
export default function App() {
  const [posts, setPosts] = useState([]);
  const [apiOk, setApiOk] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ title: "", content: "", author: "" });
  const [submitting, setSubmitting] = useState(false);

  // Check API health
  useEffect(() => {
    fetch(`${API_URL}/health`)
      .then((r) => setApiOk(r.ok))
      .catch(() => setApiOk(false));
  }, []);

  // Fetch posts
  const fetchPosts = useCallback(async () => {
    try {
      setError("");
      const res = await fetch(`${API_URL}/posts`);
      if (!res.ok) throw new Error("Failed to load posts");
      setPosts(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPosts(); }, [fetchPosts]);

  // Submit new post
  const handleSubmit = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      setError("Title and content cannot be empty.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch(`${API_URL}/posts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Failed to publish post");
      setForm({ title: "", content: "", author: "" });
      await fetchPosts();
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Delete post
  const handleDelete = async (id) => {
    try {
      await fetch(`${API_URL}/posts/${id}`, { method: "DELETE" });
      await fetchPosts();
    } catch {
      setError("Failed to delete post.");
    }
  };

  const fmt = (iso) =>
    new Date(iso).toLocaleDateString("en-IN", {
      day: "numeric", month: "short", year: "numeric",
    });

  return (
    <div style={S.app}>
      {/* Header */}
      <header style={S.header}>
        <div style={S.headerInner}>
          <h1 style={S.logo}>Inkwell</h1>
          <div style={S.status}>
            <div style={S.dot(apiOk)} />
            <span style={{ color: "#888" }}>
              {apiOk === null ? "Checking API…" : apiOk ? "API connected" : "API unreachable"}
            </span>
          </div>
        </div>
      </header>

      <main style={S.main}>
        {/* New post form */}
        <div style={S.form}>
          <p style={S.formTitle}>Write a new post</p>
          {error && <div style={S.error}>{error}</div>}
          <input
            style={S.input}
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
          />
          <textarea
            style={S.textarea}
            placeholder="What's on your mind?"
            value={form.content}
            onChange={(e) => setForm({ ...form, content: e.target.value })}
          />
          <div style={S.row}>
            <input
              style={{ ...S.input, marginBottom: 0, flex: 1 }}
              placeholder="Author (optional)"
              value={form.author}
              onChange={(e) => setForm({ ...form, author: e.target.value })}
            />
            <button
              style={S.btn("primary")}
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? "Publishing…" : "Publish"}
            </button>
          </div>
        </div>

        {/* Posts list */}
        <p style={S.sectionLabel}>
          {loading ? "Loading…" : `${posts.length} post${posts.length !== 1 ? "s" : ""}`}
        </p>

        {!loading && posts.length === 0 && (
          <div style={S.empty}>No posts yet. Write the first one above!</div>
        )}

        {posts.map((post) => (
          <div key={post.id} style={S.card}>
            <p style={S.postTitle}>{post.title}</p>
            <p style={S.postMeta}>
              By {post.author} · {fmt(post.created_at)}
            </p>
            <p style={S.postContent}>{post.content}</p>
            <button style={S.deleteBtn} onClick={() => handleDelete(post.id)}>
              Delete
            </button>
          </div>
        ))}
      </main>
    </div>
  );
}
