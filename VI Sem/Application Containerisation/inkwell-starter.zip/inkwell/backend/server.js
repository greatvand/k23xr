const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const { createClient } = require("redis");

const app = express();
app.use(cors());
app.use(express.json());

// ─── Database connection ───────────────────────────────────────────────────
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ─── Redis connection ──────────────────────────────────────────────────────
const redisClient = createClient({ url: process.env.REDIS_URL });
redisClient.on("error", (err) => console.error("Redis error:", err));

// ─── Bootstrap ────────────────────────────────────────────────────────────
async function bootstrap() {
  try {
    await redisClient.connect();
    console.log("Connected to Redis");

    await pool.query(`
      CREATE TABLE IF NOT EXISTS posts (
        id        SERIAL PRIMARY KEY,
        title     TEXT    NOT NULL,
        content   TEXT    NOT NULL,
        author    TEXT    NOT NULL DEFAULT 'Anonymous',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    console.log("Database ready");
  } catch (err) {
    console.error("Bootstrap failed:", err.message);
    process.exit(1);
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────

// Health check — used by Docker health check and the frontend to verify API
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// GET /posts — return all posts (cached in Redis for 30 seconds)
app.get("/posts", async (req, res) => {
  try {
    const cached = await redisClient.get("posts");
    if (cached) {
      console.log("Cache hit: posts");
      return res.json(JSON.parse(cached));
    }

    const result = await pool.query(
      "SELECT * FROM posts ORDER BY created_at DESC"
    );
    await redisClient.setEx("posts", 30, JSON.stringify(result.rows));
    console.log("Cache miss: posts — fetched from DB");
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch posts" });
  }
});

// POST /posts — create a new post (also invalidates the cache)
app.post("/posts", async (req, res) => {
  const { title, content, author } = req.body;

  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required" });
  }

  try {
    const result = await pool.query(
      "INSERT INTO posts (title, content, author) VALUES ($1, $2, $3) RETURNING *",
      [title, content, author || "Anonymous"]
    );
    await redisClient.del("posts"); // invalidate cache
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create post" });
  }
});

// DELETE /posts/:id — remove a post (also invalidates the cache)
app.delete("/posts/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      "DELETE FROM posts WHERE id = $1 RETURNING *",
      [id]
    );
    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Post not found" });
    }
    await redisClient.del("posts");
    res.json({ message: "Post deleted", post: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete post" });
  }
});

// ─── Start ─────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
bootstrap().then(() => {
  app.listen(PORT, () => console.log(`API running on port ${PORT}`));
});
